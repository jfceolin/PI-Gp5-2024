<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8" >
<title>PROJETO INTEGRADOR</title>
<link rel="stylesheet" href="css/style.css">
</head> 
<body>
<div class="box">
    <form action="#" method="POST">
        <div class="form-group">
            <input type="email" id="email" name="email" placeholder="E-mail" required>
        </div>
        <div class="form-group">
            <input type="password" id="senha" name="senha" placeholder="Senha" required>
            <a href="#" class="esqueci-senha">Esqueci minha senha</a>
        </div>
        <button type="submit" class="btn-submit">Novo Cadastro</button>
    </form>
</div>
</body>
</html>